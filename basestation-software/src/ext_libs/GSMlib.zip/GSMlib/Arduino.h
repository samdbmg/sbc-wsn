/*
 * Arduino.h
 *
 */

#ifndef EXT_LIBS_GSMLIB_ARDUINO_H_
#define EXT_LIBS_GSMLIB_ARDUINO_H_

// Thin wrapper around a couple of Arduino functions needed by the library

#include "printf.h"

class serialWrapper
{
public:
    void begin(void) {}
    void print(char c[]) { printf(c); }
    void println(char c[]) { printf(c); printf("\r\n"); }
};

serialWrapper Serial;

#endif /* EXT_LIBS_GSMLIB_ARDUINO_H_ */
